package otpVerification;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeMultipart;
import javax.mail.search.FlagTerm;


import propertyReader.PropertyReader;

/**
 * This class is to fetch OTP from email.
 * 
 * @author sagar.malik
 * 
 */

public class OTPVerficationFromMail{
//	String hostName = "smtp.mail.yahoo.com";
	
//	
//	static String hostName = "smtp.gmail.com";
//	static String username = "sahuja014@gmail.com";
//	static String password = "Mycantos@1";
	int messageCount;
	int unreadMsgCount;
	String emailSubject;
	Message emailMessage;
	static HashMap<String, String> emailPropertyMap;

	
	public static void main(String args[]) throws FileNotFoundException, IOException {

//		Runtime.getRuntime().exec("cmd /c start cmd.exe /K \"cd D:\\NAGP\\Selenium\\Sachin_4597_SeleniumProject\" /K \"mvn clean test\"");
				String str="";
		try {
			emailPropertyMap=new PropertyReader().getProperties(System.getProperty("user.dir")+"\\src\\main\\java\\otpVerification\\otp.properties");			
			new OTPVerficationFromMail().mailReader(emailPropertyMap.get("hostName"), emailPropertyMap.get("username"), emailPropertyMap.get("password")) ;			
		}
		catch (Exception e) {
			
		}
	}

	/**
	 * mailReader
	 * This function is to extract the OTP from the mail.
	 * @param hostName The host name of the gmail/any email account
	 * @param username The user name of the gmail/any email account
	 * @param password The password of the gmail/any email account
	 * @return string This function returns the value in string 
	 */
	public void mailReader(String hostName, String username, String password) {
		
		String suiteList ="";
		boolean flag=false;
	    Properties sysProps = System.getProperties();
	    sysProps.setProperty(emailPropertyMap.get("systemProperty"), emailPropertyMap.get("protocol"));
	    

	    try {
	        Session session = Session.getInstance(sysProps, null);
	        Store store = session.getStore();	       
	        store.connect(hostName, username, password);
	        Folder emailInbox = store.getFolder("INBOX");
	        emailInbox.open(Folder.READ_WRITE);
	        messageCount = emailInbox.getMessageCount();
	        unreadMsgCount = emailInbox.getNewMessageCount();
	        
	        
	        
	        Message[] emailMessages = emailInbox.search(
					new FlagTerm(new Flags(Flags.Flag.SEEN), false));
	        for(int i=emailMessages.length-1;i>=0;i--) {
	        	Message emailMessage=emailMessages[i];
		        emailSubject = emailMessage.getSubject();
		        System.out.println(emailSubject);
		        emailMessage.setFlag(Flags.Flag.SEEN, true);
		        if (emailSubject.toLowerCase().contains("Execute Autothon Test".toLowerCase())) {
		        	String []suites=emailSubject.split(":")[1].trim().split(",");
		        	for(String s:suites) {
		        		suiteList=suiteList+";"+s;
		        		String folder = OTPVerficationFromMail.class.getProtectionDomain().getCodeSource().getLocation().getPath();

//		        		Runtime.getRuntime().exec("cmd.exe /c cd \""+folder+"\" & start cmd.exe /k \"mvn clean test -DsuiteXmlFile=RegressionSuite.xml\"");

		        		Runtime.getRuntime().exec("cmd.exe /c cd \"D:\\NAGP\\Selenium\\Sachin_4597_SeleniumProject\" & start cmd.exe /k \"mvn clean test -DsuiteXmlFile=RegressionSuite.xml\"");

//		        		Runtime.getRuntime().exec("cmd /c start cmd.exe /K \"cd D:\\NAGP\\Selenium\\Sachin_4597_SeleniumProject\" cmd.exe /K \"mvn clean test -DsuiteXmlFile="+suiteList +"\"");   		
		        	}		           
		            flag=true;
		        }
	        }
	        emailInbox.close(true);
	        store.close();
	        
	        if(flag==true) {
	        	Runtime.getRuntime().exec("cmd.exe"); 
	        }
	        
	        System.getProperty("suiteList");
	        
	        
	    } catch (Exception mex) {
	        mex.printStackTrace();
	    }
	}
	
	private String getTextFromMessage(Message message) throws MessagingException, IOException {
	    String result = "";
	    if (message.isMimeType("text/plain")) {
	        result = message.getContent().toString();
	    } else if (message.isMimeType("multipart/*")) {
	        MimeMultipart mimeMultipart = (MimeMultipart) message.getContent();
	        result = getTextFromMimeMultipart(mimeMultipart);
	    }
	    return result;
	}

	private String getTextFromMimeMultipart(
	        MimeMultipart mimeMultipart)  throws MessagingException, IOException{
	    String result = "";
	    int count = mimeMultipart.getCount();
	    for (int i = 0; i < count; i++) {
	        BodyPart bodyPart = mimeMultipart.getBodyPart(i);
	        if (bodyPart.isMimeType("text/plain")) {
	            result = result + "\n" + bodyPart.getContent();
	            break; // without break same text appears twice in my tests
	        } else if (bodyPart.getContent() instanceof MimeMultipart){
	            result = result + getTextFromMimeMultipart((MimeMultipart)bodyPart.getContent());
	        }
	    }
	    return result;
	}
}